# Abandoned but Not Forgotten

An interactive, story-driven page about the NASA machines left on the Moon and Mars: what each one did, what it discovered, and when it fell silent. Built for NASA Space Apps Cairo.

Single file, no build step: open `index.html` in a browser.

## Publish on GitHub Pages (free link)

1. Create a new repository and upload `index.html` and `README.md`.
2. Go to **Settings > Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
4. After a minute your link appears: `https://<your-username>.github.io/<repo-name>/`

## Sources

NASA Apollo Lunar Surface Journal, NASA NSSDCA, NASA JPL, NASA NTRS, and the other articles listed at the bottom of the page.
